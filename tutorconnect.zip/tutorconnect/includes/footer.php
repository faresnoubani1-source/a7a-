    </main>
    <footer class="site-footer">
        <p>&copy; <?= date('Y') ?> TutorConnect. Built for CS355 Web Technologies Lab.</p>
        <p>Secure PHP demo: PDO queries, hashed passwords, CSRF forms, and protected uploads.</p>
    </footer>
    <script src="<?= e(url_for('assets/js/app.js')) ?>"></script>
</body>
</html>
