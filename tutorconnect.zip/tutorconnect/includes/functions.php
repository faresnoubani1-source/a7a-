<?php
declare(strict_types=1);

function e(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function url_for(string $path = ''): string
{
    $path = ltrim($path, '/');
    return BASE_URL . '/' . $path;
}

function redirect(string $path): never
{
    header('Location: ' . url_for($path));
    exit;
}

function flash(string $type, string $message): void
{
    $_SESSION['flashes'][] = ['type' => $type, 'message' => $message];
}

function consume_flashes(): array
{
    $flashes = $_SESSION['flashes'] ?? [];
    unset($_SESSION['flashes']);
    return $flashes;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf(): void
{
    $token = $_POST['csrf_token'] ?? '';

    if (!is_string($token) || !hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        http_response_code(419);
        exit('Security check failed. Please go back and submit the form again.');
    }
}

function current_user(): ?array
{
    static $user = null;

    if ($user !== null) {
        return $user;
    }

    if (empty($_SESSION['user_id'])) {
        return null;
    }

    global $pdo;
    $stmt = $pdo->prepare(
        "SELECT id, first_name, last_name, CONCAT(first_name, ' ', last_name) AS full_name, email, phone, role, created_at
         FROM users
         WHERE id = ?
         LIMIT 1"
    );
    $stmt->execute([(int) $_SESSION['user_id']]);
    $user = $stmt->fetch() ?: null;

    if ($user === null) {
        unset($_SESSION['user_id']);
    }

    return $user;
}

function is_logged_in(): bool
{
    return current_user() !== null;
}

function require_login(): void
{
    if (!is_logged_in()) {
        flash('warning', 'Please sign in before using that page.');
        redirect('signin.php');
    }
}

function format_money(float|string $amount): string
{
    return '$' . number_format((float) $amount, 2);
}

function status_label(string $status): string
{
    return match ($status) {
        'pending' => 'Awaiting payment',
        'confirmed' => 'Confirmed',
        'cancelled' => 'Cancelled',
        'completed' => 'Completed',
        default => ucfirst($status),
    };
}

function status_class(string $status): string
{
    return match ($status) {
        'confirmed' => 'success',
        'pending' => 'warning',
        'cancelled' => 'danger',
        'completed' => 'muted',
        default => 'muted',
    };
}

function valid_future_session(string $date, string $time): bool
{
    $dateTime = DateTime::createFromFormat('Y-m-d H:i', $date . ' ' . $time);

    if (!$dateTime) {
        return false;
    }

    return $dateTime > new DateTime('+30 minutes');
}

function selected(string $actual, string $expected): string
{
    return $actual === $expected ? ' selected' : '';
}

function checked(bool $condition): string
{
    return $condition ? ' checked' : '';
}

function validate_password_strength(string $password, string $firstName, string $lastName, string $email): array
{
    $errors = [];

    if (strlen($password) < 10) {
        $errors[] = 'Password must be at least 10 characters.';
    }

    if (strlen($password) > 72) {
        $errors[] = 'Password must be 72 characters or fewer.';
    }

    if (!preg_match('/[a-z]/', $password)) {
        $errors[] = 'Password must include a lowercase letter.';
    }

    if (!preg_match('/[A-Z]/', $password)) {
        $errors[] = 'Password must include an uppercase letter.';
    }

    if (!preg_match('/[0-9]/', $password)) {
        $errors[] = 'Password must include a number.';
    }

    if (!preg_match('/[^A-Za-z0-9]/', $password)) {
        $errors[] = 'Password must include a special character.';
    }

    if (preg_match('/\s/', $password)) {
        $errors[] = 'Password cannot contain spaces.';
    }

    $lowerPassword = strtolower($password);
    $blockedWords = ['password', '123456', 'qwerty', 'admin', 'tutorconnect'];

    foreach ($blockedWords as $word) {
        if (strpos($lowerPassword, $word) !== false) {
            $errors[] = 'Password cannot contain common words or simple sequences.';
            break;
        }
    }

    $emailUser = strtolower(strtok($email, '@') ?: '');
    $personalParts = [strtolower($firstName), strtolower($lastName), $emailUser];

    foreach ($personalParts as $part) {
        if (strlen($part) >= 3 && strpos($lowerPassword, $part) !== false) {
            $errors[] = 'Password cannot contain your name or email username.';
            break;
        }
    }

    return $errors;
}

function upload_error_message(int $error): string
{
    return match ($error) {
        UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'The file is larger than the allowed upload size.',
        UPLOAD_ERR_PARTIAL => 'The file upload did not finish. Please try again.',
        UPLOAD_ERR_NO_FILE => 'Please choose a file to upload.',
        default => 'The upload failed. Please try another file.',
    };
}

function store_uploaded_resource(array $file): array
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        throw new RuntimeException(upload_error_message((int) ($file['error'] ?? UPLOAD_ERR_NO_FILE)));
    }

    if (($file['size'] ?? 0) > MAX_UPLOAD_SIZE) {
        throw new RuntimeException('Files must be 5 MB or smaller.');
    }

    $allowed = [
        'application/pdf' => ['ext' => 'pdf', 'extensions' => ['pdf']],
        'application/msword' => ['ext' => 'doc', 'extensions' => ['doc']],
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => ['ext' => 'docx', 'extensions' => ['docx']],
        'application/vnd.ms-powerpoint' => ['ext' => 'ppt', 'extensions' => ['ppt']],
        'application/vnd.openxmlformats-officedocument.presentationml.presentation' => ['ext' => 'pptx', 'extensions' => ['pptx']],
        'image/jpeg' => ['ext' => 'jpg', 'extensions' => ['jpg', 'jpeg']],
        'image/png' => ['ext' => 'png', 'extensions' => ['png']],
        'text/plain' => ['ext' => 'txt', 'extensions' => ['txt']],
    ];

    $tmpName = (string) $file['tmp_name'];
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mimeType = $finfo->file($tmpName) ?: '';
    $submittedExtension = strtolower(pathinfo((string) $file['name'], PATHINFO_EXTENSION));

    if (!isset($allowed[$mimeType]) || !in_array($submittedExtension, $allowed[$mimeType]['extensions'], true)) {
        throw new RuntimeException('Allowed files: PDF, Word, PowerPoint, JPG, PNG, or TXT.');
    }

    if (!is_dir(UPLOAD_DIR)) {
        mkdir(UPLOAD_DIR, 0755, true);
    }

    $storedName = bin2hex(random_bytes(18)) . '.' . $allowed[$mimeType]['ext'];
    $destination = UPLOAD_DIR . DIRECTORY_SEPARATOR . $storedName;

    if (!move_uploaded_file($tmpName, $destination)) {
        throw new RuntimeException('Could not save the uploaded file.');
    }

    return [
        'original_name' => basename((string) $file['name']),
        'stored_name' => $storedName,
        'mime_type' => $mimeType,
        'file_size' => (int) $file['size'],
    ];
}

function human_file_size(int $bytes): string
{
    if ($bytes >= 1024 * 1024) {
        return number_format($bytes / (1024 * 1024), 2) . ' MB';
    }

    if ($bytes >= 1024) {
        return number_format($bytes / 1024, 1) . ' KB';
    }

    return $bytes . ' bytes';
}

function owned_booking_options(int $userId): array
{
    global $pdo;

    $stmt = $pdo->prepare(
        "SELECT b.id, b.session_date, b.session_time, b.status, t.name AS tutor_name, t.subject
         FROM bookings b
         INNER JOIN tutors t ON t.id = b.tutor_id
         WHERE b.user_id = ? AND b.status IN ('pending', 'confirmed')
         ORDER BY b.session_date, b.session_time"
    );
    $stmt->execute([$userId]);

    return $stmt->fetchAll();
}
