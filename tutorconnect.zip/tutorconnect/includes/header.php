<?php
$pageTitle = $pageTitle ?? APP_NAME;
$activePage = basename($_SERVER['PHP_SELF']);
$signedInUser = current_user();
$flashes = consume_flashes();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($pageTitle) ?> | <?= APP_NAME ?></title>
    <link rel="stylesheet" href="<?= e(url_for('assets/css/styles.css')) ?>">
</head>
<body>
<header class="site-header">
    <a class="brand" href="<?= e(url_for('index.php')) ?>" aria-label="TutorConnect home">
        <span class="brand-mark">TC</span>
        <span>TutorConnect</span>
    </a>
    <button class="nav-toggle" type="button" data-nav-toggle aria-label="Open navigation">
        <span></span>
        <span></span>
        <span></span>
    </button>
    <nav class="main-nav" data-main-nav>
        <a class="<?= $activePage === 'index.php' ? 'active' : '' ?>" href="<?= e(url_for('index.php')) ?>">Home</a>
        <a class="<?= $activePage === 'tutors.php' ? 'active' : '' ?>" href="<?= e(url_for('tutors.php')) ?>">Tutors</a>
        <?php if ($signedInUser): ?>
            <a class="<?= $activePage === 'dashboard.php' ? 'active' : '' ?>" href="<?= e(url_for('dashboard.php')) ?>">Dashboard</a>
            <a class="<?= $activePage === 'my_bookings.php' ? 'active' : '' ?>" href="<?= e(url_for('my_bookings.php')) ?>">Bookings</a>
            <a class="<?= $activePage === 'resources.php' ? 'active' : '' ?>" href="<?= e(url_for('resources.php')) ?>">Materials</a>
            <form class="nav-logout" action="<?= e(url_for('logout.php')) ?>" method="post">
                <?= csrf_field() ?>
                <button class="link-button" type="submit">Sign out</button>
            </form>
        <?php else: ?>
            <a class="<?= $activePage === 'signin.php' ? 'active' : '' ?>" href="<?= e(url_for('signin.php')) ?>">Sign in</a>
            <a class="nav-pill <?= $activePage === 'signup.php' ? 'active' : '' ?>" href="<?= e(url_for('signup.php')) ?>">Sign up</a>
        <?php endif; ?>
    </nav>
</header>
<main class="page-shell">
    <?php foreach ($flashes as $flash): ?>
        <div class="flash flash-<?= e($flash['type']) ?>">
            <?= e($flash['message']) ?>
        </div>
    <?php endforeach; ?>
